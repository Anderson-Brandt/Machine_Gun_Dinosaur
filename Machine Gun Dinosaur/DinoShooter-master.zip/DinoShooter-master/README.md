# DinoShooter
Projeto completo do jogo Dino Shooter. 

Esse jogo foi desenvolvido como tutorial do canal Programando Games.

PARTE 1:
https://www.youtube.com/watch?v=M22tbRcVm7k

PARTE 2:
https://www.youtube.com/watch?v=p3pL4eJnmjY

Fique livre para usar o projeto como quiser, só peço que dê referências ao canal ou compartilhe os vídeos :)


Qualquer dúvida, entre em contato pelo email:
jaibortolucci@gmail.com
